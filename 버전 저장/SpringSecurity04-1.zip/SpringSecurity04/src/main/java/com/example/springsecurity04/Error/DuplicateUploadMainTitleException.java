package com.example.springsecurity04.Error;

public class DuplicateUploadMainTitleException extends RuntimeException {

    public DuplicateUploadMainTitleException(String message){
        super(message);
    }
}
