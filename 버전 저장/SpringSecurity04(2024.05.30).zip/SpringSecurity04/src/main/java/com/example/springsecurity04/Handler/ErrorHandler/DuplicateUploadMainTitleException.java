package com.example.springsecurity04.Handler.ErrorHandler;

public class DuplicateUploadMainTitleException extends RuntimeException {

    public DuplicateUploadMainTitleException(String message){
        super(message);
    }
}
