package com.example.springsecurity04.Test;

@FunctionalInterface
public interface Calculator {

    String getSum();
}
