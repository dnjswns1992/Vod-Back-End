package com.example.springsecurity04;

public class Test01 {

    public static void main(String[] args) {

    }
}