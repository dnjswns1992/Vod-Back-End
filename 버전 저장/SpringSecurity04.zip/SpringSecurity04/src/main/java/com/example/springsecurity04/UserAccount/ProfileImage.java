package com.example.springsecurity04.UserAccount;

public abstract class ProfileImage {
    public static final String profileImage = "C:\\Users\\WooHeeSeop\\Desktop\\VodProject\\ProJectImage\\profile.png";

}
